package com.example.myapplication3

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import com.example.myapplication3.databinding.ActivityMainBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

const val CHANNEL_ID = "channelId"
class MainActivity : AppCompatActivity() {

    // view binding
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    // firebase auth
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // init firbase auth
        firebaseAuth = FirebaseAuth.getInstance()
        auth = Firebase.auth

        setSupportActionBar(binding.appBarMain.toolbar)

        // Button to add a pdf :

        binding.appBarMain.addbook.setOnClickListener { view ->
            Snackbar.make(view, "Add or review new book", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            startActivity(Intent(this, AddActivity::class.java))
        }


        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_your_books, R.id.nav_your_reviews, R.id.nav_want_to_read,
                R.id.nav_bookstores, R.id.nav_favorites, R.id.nav_your_goals
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        val firebaseUser = auth.currentUser!!
        val email = firebaseUser.email
        //val navHeader = binding.navView.getHeaderView(0)
        //val navUsername = navHeader.findViewById(R.id.loginemail)
        //navHeader.text(firebaseUser.email)
        //val navUsername = navHeader.findViewById<TextView>(R.id.loginemail)
        //navUsername.text = email
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        val txtProfileEmail: TextView = navigationView.getHeaderView(0).findViewById(R.id.username)
        txtProfileEmail.text = email

        //val currentUser = database.child("Users").child(firebaseUser.uid).get()
        //val txtProfileName: TextView = navigationView.getHeaderView(0).findViewById(R.id.username)
        //txtProfileName.text = currentUser

        createNotificationChannel()

        var builder = NotificationCompat.Builder(this, CHANNEL_ID)
        builder.setSmallIcon(R.drawable.round_tag_faces_24)
            .setContentTitle("Time to Read!!")
            .setContentTitle("Hey you! " +
                    "We missed you! Do not forget to record your readings")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(this)){
            if (ActivityCompat.checkSelfPermission(
                    applicationContext
                    ,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            notify(1, builder.build())
        }


    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val channel = NotificationChannel(CHANNEL_ID, "First channel",
                NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "Test description for the channel"

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()

    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                val intent = Intent(this, Setting::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun checkUser(){
        // login
        val firebaseUser = auth.currentUser
        if (firebaseUser == null){
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        else {
            val email = firebaseUser.email
            //val navHeader = binding.navView.getHeaderView(0)
            //val navUsername = navHeader.findViewById(R.id.loginemail)
            //navHeader.text(firebaseUser.email)
            //val navUsername = navHeader.findViewById<TextView>(R.id.loginemail)
            //navUsername.text = email
            val navigationView: NavigationView = findViewById(R.id.nav_view)
            //navigationView.setNavigationItemSelectedListener()
            val txtProfileName: TextView =
                navigationView.getHeaderView(0).findViewById(R.id.loginemail)
            txtProfileName.text = email

        }

    }
}