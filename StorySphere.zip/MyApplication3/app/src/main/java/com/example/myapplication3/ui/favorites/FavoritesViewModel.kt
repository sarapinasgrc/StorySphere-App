package com.example.myapplication3.ui.favorites

import androidx.lifecycle.ViewModel

class FavoritesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}