package com.example.myapplication3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import com.example.myapplication3.databinding.ActivityPdfDetailBinding
import com.example.myapplication3.databinding.ActivityReviewDisplayBinding
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class ReviewDisplayActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReviewDisplayBinding

    private var reviewId = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        reviewId = intent.getStringExtra("reviewId")!!

        loadReviewDetails()

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }


    }

    private fun loadReviewDetails() {
        val ref =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Reviews").child(reviewId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // get data
                    val review = "${snapshot.child("review").value}"
                    val timestamp = "${snapshot.child("timestamp").value}"
                    val title = "${snapshot.child("title").value}"
                    val uid = "${snapshot.child("uid").value}"
                    val score = "${snapshot.child("score").value}"

                    // format date
                    val date = ApplicationFunctions.formatTimestamp(timestamp.toLong())

                    binding.titleTv.text = title
                    binding.bookreviewTv.text = review
                    binding.dateTv.text = date
                    binding.scoreTv.text = score


                }

                override fun onCancelled(error: DatabaseError) {

                }


            })
    }

}