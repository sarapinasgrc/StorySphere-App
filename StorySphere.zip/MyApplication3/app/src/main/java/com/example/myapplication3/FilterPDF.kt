package com.example.myapplication3

import android.widget.Filter

/* used to filter data from recyclerview*/
class FilterPDF : Filter{
    val filterList: ArrayList<DisplayPDF>
    val adapterPdf: AdapterPDF

    // constructor
    constructor(filerList: ArrayList<DisplayPDF>, adapterPdf: AdapterPDF) {
        this.filterList = filerList
        this.adapterPdf = adapterPdf
    }

    override fun performFiltering(constraint: CharSequence?): FilterResults {
        var constraint:CharSequence? = constraint
        var results = FilterResults()
        // value to be searched should not be null and not be empty
        if (constraint != null && constraint.isNotEmpty()){
            // avoid case sensitive problems
            constraint = constraint.toString().lowercase()
            var filteredModels = ArrayList<DisplayPDF>()
            for (i in filterList.indices){
                // validate if match
                if (filterList[i].title.lowercase().contains(constraint)){
                    // searched value is similar to value in list, add to filtered list
                    filteredModels.add(filterList[i])
                }
            }
            results.count = filteredModels.size
            results.values = filteredModels
        }
        else {
            // searched value is either null or empty, return all data
            results.count = filterList.size
            results.values = filterList

        }
        return results

    }

    override fun publishResults(constraint: CharSequence, results: FilterResults) {
        //apply filter changes
        adapterPdf.pdfArrayList = results.values as ArrayList<DisplayPDF>

        // notify changes
        adapterPdf.notifyDataSetChanged()
    }
}