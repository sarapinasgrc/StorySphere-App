package com.example.myapplication3

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication3.databinding.ActivityDisplayBookBinding
import android.content.Context
import android.content.Intent
import android.widget.Filter
import android.widget.Filterable

class AdapterPDF : RecyclerView.Adapter<AdapterPDF.HolderPdfAdmin> {
    // context
    private var context: Context

    // array list to hold pdfs
    var pdfArrayList: ArrayList<DisplayPDF>
    //private val filterList:ArrayList<DisplayPDF>

    // view Binding
    private lateinit var binding: ActivityDisplayBookBinding

    // filter object
    //var filter: FilterPDF? = null

    // constructor
    constructor(context: Context, pdfArrayList: ArrayList<DisplayPDF>) : super() {
        this.context = context
        this.pdfArrayList = pdfArrayList
        //this.filterList = pdfArrayList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderPdfAdmin {
        //bind/inflate layout activity_display_book.xml
        binding = ActivityDisplayBookBinding.inflate(LayoutInflater.from(context), parent, false)
        return HolderPdfAdmin(binding.root)
    }

    override fun onBindViewHolder(holder: AdapterPDF.HolderPdfAdmin, position: Int) {
        /*get data, set data, handle click, etc*/
        // get data
        val model = pdfArrayList[position]
        val pdfId = model.id
        val title = model.title
        val description = model.description
        val pdfURL = model.url
        val timestamp = model.timestamp
        // convert timestamp to dd/MM/yyyy
        val formattedDate = ApplicationFunctions.formatTimestamp(timestamp)

        // create Application class that contains the functions that will be used multiple times in the app

        // set data
        holder.titleTv.text = title
        holder.descriptionTv.text = description
        holder.dateTv.text = formattedDate

        // load pdf from url, pdf size
        ApplicationFunctions.loadPdfFromUrlSinglePage(
            pdfURL,
            title,
            holder.pdfView,
            holder.progressBar,
            null
        )

        ApplicationFunctions.loadPdfSize(pdfURL, title, holder.sizeTv)

        // handle click, show dialog with 1) Edit and 2) Delete Book
        holder.moreBtn.setOnClickListener{
            moreOptionsDialog(model, holder)
    }

        // handle item click, open PdfDetailActivity
        holder.itemView.setOnClickListener{
            val intent = Intent(context, PDFDetailInformation::class.java)
            intent.putExtra("pdfId", pdfId)
            context.startActivity(intent)
        }


    }

    private fun moreOptionsDialog(model: DisplayPDF, holder: AdapterPDF.HolderPdfAdmin) {
        val pdfId = model.id
        val pdfUrl = model.url
        val pdfTitle = model.title

        // options to show in dialog
        val options = arrayOf("Edit", "Delete")

        // alert dialog
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Choose Option")
            .setItems(options){dialog, position ->
                // handle item click
                if(position==0){
                    // Edit is clicked
                    val intent = Intent(context, PDFEditActivity::class.java)
                    intent.putExtra("pdfId", pdfId)
                    context.startActivity(intent)
                }
                else if (position == 1){
                    // Delete is clicked

                    ApplicationFunctions.deleteBook(context, pdfId, pdfUrl, pdfTitle)
                }
            }
            .show()
    }





    override fun getItemCount(): Int {
        return pdfArrayList.size //items count
    }


    //override fun getFilter(): Filter {
    //    if (filter == null){
    //        //filter = FilterPDF(filterList, this)
    //    }
    //    return filter as FilterPDF
    //}

    inner class HolderPdfAdmin(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // UI views of activity_display_book.xml
        val pdfView = binding.pdfView
        val progressBar = binding.progressBar
        val titleTv = binding.titleTv
        val descriptionTv = binding.descriptionTv
        val sizeTv = binding.sizeTv
        val dateTv = binding.dateTv
        val moreBtn = binding.moreBtn
    }


}

