package com.example.myapplication3.ui.reviews

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.myapplication3.AdapterReview
import com.example.myapplication3.DisplayReview
import com.example.myapplication3.databinding.FragmentReviewsBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class ReviewsFragment : Fragment() {

    companion object {
        fun newInstance() = ReviewsFragment()
    }

    private lateinit var binding: FragmentReviewsBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private val reviewArrayList: ArrayList<DisplayReview> = ArrayList()
    private lateinit var adapterReview: AdapterReview

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReviewsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        firebaseAuth = FirebaseAuth.getInstance()
        loadReviewList()
    }

    private fun loadReviewList() {
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        val user = firebaseAuth.currentUser
        val ref = database.child("Reviews")

        adapterReview = AdapterReview(requireContext(), reviewArrayList)
        binding.bookRv.adapter = adapterReview

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                reviewArrayList.clear()
                for (ds in snapshot.children) {
                    val uid = ds.child("uid").getValue(String::class.java)
                    if (uid == user?.uid) {
                        val model = ds.getValue(DisplayReview::class.java)
                        model?.let {
                            reviewArrayList.add(it)
                        }
                    }
                }
                adapterReview.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled event
            }
        })
    }
}

