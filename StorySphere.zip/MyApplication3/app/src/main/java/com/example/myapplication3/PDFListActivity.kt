package com.example.myapplication3

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication3.databinding.ActivityDisplayBookBinding
import com.example.myapplication3.databinding.ActivityDisplayBookBinding.inflate
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import android.view.LayoutInflater
import com.example.myapplication3.R
import com.example.myapplication3.databinding.ActivityPdfbookBinding
import com.example.myapplication3.databinding.FragmentYourBooksBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.database


class PDFListActivity : AppCompatActivity() {

    // view binding
    private lateinit var binding: FragmentYourBooksBinding

    private lateinit var firebaseAuth: FirebaseAuth
    private companion object {
        const val TAG = "PDF_LIST"
    }

    private var pdfId = ""
    private var pdf = ""

    // arraylist to hold books
    private lateinit var pdfArrayList:ArrayList<DisplayPDF>
    //adapter
    private lateinit var adapterPdf: AdapterPDF



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentYourBooksBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //val intent = intent
        //pdfId = intent.getStringExtra("pdfId")!!
        //pdf = intent.getStringExtra("title")!!
        firebaseAuth = FirebaseAuth.getInstance()
        loadPdfList()

    }


    private fun loadPdfList() {
        //init arraylist
        pdfArrayList = ArrayList()
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        firebaseAuth = FirebaseAuth.getInstance()
        val user = firebaseAuth.currentUser!!
        val ref = database.child("Books")
        binding.bookRv.adapter =
            AdapterPDF(this@PDFListActivity, pdfArrayList) // Set a placeholder adapter initially

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                pdfArrayList.clear()
                for (ds in snapshot.children) {
                    val uid = ds.child("uid").getValue(String::class.java)
                    if (uid == user.uid) {
                        val model = ds.getValue(DisplayPDF::class.java)
                        if (model != null) {
                            pdfArrayList.add(model)
                            Log.d(TAG, "onDataChange: ${model.title} ${model.id}")
                        }
                    }
                }
                adapterPdf = AdapterPDF(this@PDFListActivity, pdfArrayList)
                binding.bookRv.adapter = adapterPdf
                binding.bookRv.requestLayout()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled event
            }
        })


    }
}