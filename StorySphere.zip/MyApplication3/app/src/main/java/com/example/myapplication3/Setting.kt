package com.example.myapplication3

import android.app.Activity
import android.app.ProgressDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.Menu
import android.widget.ImageButton
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
//import com.bumptech.glide.Glide
import com.example.myapplication3.databinding.ActivitySettingBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.Firebase
import com.google.firebase.auth.ActionCodeUrl
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import com.google.firebase.database.getValue
import com.google.firebase.storage.FirebaseStorage

class Setting : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth

    private var imageUri:Uri? = null
    val database =
        Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //loadUserInfo()
        //showImage()



        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Wait")
        progressDialog.setCanceledOnTouchOutside(false)

        //firebaseAuth = FirebaseAuth.getInstance()
        auth = Firebase.auth
        firebaseAuth = FirebaseAuth.getInstance()
        val user = firebaseAuth.currentUser!!
        val email = user.email
        val uid = user.uid
        database.child("Users").child(uid).addValueEventListener(
            object :ValueEventListener{
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val user_name = "${dataSnapshot.child("name").value}"
                    binding.name.text = user_name
                }
                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            }
        )
        //val name = user.
        val names = firebaseAuth.currentUser!!.displayName.toString()


        //binding.name.text = user_name
        binding.emailtext.text = email

        binding.savechanges.setOnClickListener{
            validateData()
        }

        //binding.perfil.setOnClickListener{
        //uploadImage()
        //}

        val button = findViewById<ImageButton>(R.id.backbtn)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }

    private var name = ""
    private var email= ""
    private var password = ""
    private fun validateData() {
        name = binding.nameprf.text.toString().trim()
        email = binding.emailprf.text.toString().trim()
        updateProfile()
        //password= binding.newpasswordprf.text.toString().trim()
        //val cpassword= binding.newcpasswordprf.text.toString().trim()

        //if (password.isNotEmpty()){
            //if(cpassword.isEmpty()){
                //Toast.makeText(this, "Confirm your password", Toast.LENGTH_SHORT).show()
           // }
            //else if(password != cpassword){
                //Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show()
            //}
        //}
        //else{
            //updateProfile()
        //}
    }

    private fun updateProfile() {
        progressDialog.setMessage("Updating Profile")
        val timestamp = System.currentTimeMillis()

        // get current user uid since user is registered so we can get it now
        val user = auth.currentUser
        val uid = user!!.uid

        val hashmap: HashMap<String, Any> = HashMap()
        hashmap["uid"] = uid

        if (name.isNotEmpty()) {
            hashmap["name"] = name
        }
        if (email.isNotEmpty()) {
            if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                hashmap["email"] = email
            } else {
                // Show error message indicating invalid email format
                Toast.makeText(this, "Invalid email format", Toast.LENGTH_SHORT).show()
                return // Return from the function since email format is invalid
            }
        }

        hashmap["timestamp"] = timestamp

        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        database.child("Users").child(uid)
            .updateChildren(hashmap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Profile updated successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to update profile due to ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadUserInfo() {
        //val database =
            //Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        val user = auth.currentUser
        val uid = user!!.uid
        //val ref = database.child("Users").child(uid)

        database.child("Users").child(uid)
            .addValueEventListener(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    val email = snapshot.child("email").getValue(String::class.java)
                    val name = snapshot.child("name").getValue(String::class.java)
                    //val profileImage = "${snapshot.child("profileImage").value}"
                    //val uid = "${snapshot.child("uid").value}"

                    binding.name.text = name
                    binding.emailtext.text = email

                    //for the profile image
                    //try {
                    //Glide.with(this@Setting).load(profileImage)
                    //.placeholder(R.drawable.person).into(binding.perfil)
                    //}
                    //catch (e: Exception){

                    //}

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
    }


    //private fun uploadImage(){
    //    val filePathAndName = "ProfileImages/"+firebaseAuth.uid

    //    val reference = FirebaseStorage.getInstance().getReference(filePathAndName)
    //    reference.putFile(imageUri!!)
    //        .addOnSuccessListener { taskSnapshot->
    //            val uriTask: Task<Uri> = taskSnapshot.storage.downloadUrl
    //            while (!uriTask.isSuccessful);
    //                val uploadedImageUrl = "${uriTask.result}"

    //                updateProfile(uploadedImageUrl)
    //        }
    //        .addOnFailureListener{e->
    //            Toast.makeText(this, "Failed to upload image due to ${e.message}", Toast.LENGTH_SHORT).show()

    //        }
    //}

    //private fun showImage() {
    //    val popup = PopupMenu(this, binding.perfil)
    //    popup.menu.add(Menu.NONE, 0, 0, "Gallery")
    //    popup.show()

    //    popup.setOnMenuItemClickListener { item ->
    //        item?.let {
    //            val id = it.itemId
    //            if (id == 0) {
    //                pickImageGallery()
    //                return@setOnMenuItemClickListener true
    //            }
    //        }
    //        return@setOnMenuItemClickListener false
    //    }
    //}


    //private fun pickImageGallery(){
    //    val intent = Intent(Intent.ACTION_PICK)
    //    intent.type = "image/*"
    //    galleryActivityResultLauncher.launch(intent)
    //}
    //private val galleryActivityResultLauncher = registerForActivityResult(
    //    ActivityResultContracts.StartActivityForResult(),
    //    ActivityResultCallback<ActivityResult>{result ->
    //        if (result.resultCode == Activity.RESULT_OK){
    //            val data = result.data
    //            imageUri = data!!.data

    //            binding.perfil.setImageURI(imageUri)
    //        }
    //        else{
    //            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
    //        }

    //    }
    //)



}