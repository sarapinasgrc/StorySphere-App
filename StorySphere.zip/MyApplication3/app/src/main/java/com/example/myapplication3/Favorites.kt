package com.example.myapplication3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication3.R

class Favorites : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)
    }
}