package com.example.myapplication3.ui.goals

import androidx.lifecycle.ViewModel

class YourGoalsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}