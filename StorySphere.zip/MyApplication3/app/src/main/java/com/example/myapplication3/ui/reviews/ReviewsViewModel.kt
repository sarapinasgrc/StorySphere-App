package com.example.myapplication3.ui.reviews

import androidx.lifecycle.ViewModel

class ReviewsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}