package com.example.myapplication3.ui.books

import androidx.lifecycle.ViewModel

class YourBooksViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}