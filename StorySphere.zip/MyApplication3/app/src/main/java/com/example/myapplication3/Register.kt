package com.example.myapplication3

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import com.example.myapplication3.databinding.ActivityRegisterBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.database
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.database.DatabaseReference

class Register : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    //firebase auth
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth

    //progress dialog
    private lateinit var progressDialog: ProgressDialog

    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // handle back button
        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        // init firebase auth
        //firebaseAuth = FirebaseAuth.getInstance()
        auth = Firebase.auth

        // init progress dialog, will show while creating account/ registr user
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("please wait")
        progressDialog.setCanceledOnTouchOutside(false)

        //handle click, begin register
        binding.registerBtn.setOnClickListener {
            // 1 input data
            // 2 validate data
            // 3 create account- firebase auth
            //4 save user info- firebase realtime database
            validateData()
        }


    }


    private var username = ""
    private var email= ""
    private var password = ""

    private fun validateData(){
        // 1 input data
        username = binding.username.text.toString().trim()
        email= binding.email.text.toString().trim()
        password= binding.password.text.toString().trim()
        val cpassword= binding.cpassword.text.toString().trim()

        // 2 validate data
        if (username.isEmpty()){
            //empty name...
            Toast.makeText(this, "Enter your username", Toast.LENGTH_SHORT).show()
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            // invalid email pattern
            Toast.makeText(this, "Invalid email pattern", Toast.LENGTH_SHORT).show()
        }
        else if(password.isEmpty()){
            Toast.makeText(this, "Enter your password", Toast.LENGTH_SHORT).show()
        }
        else if(cpassword.isEmpty()){
            Toast.makeText(this, "Confirm your password", Toast.LENGTH_SHORT).show()
        }
        else if(password != cpassword){
            Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show()
        }
        else{
            createUserAccount()
        }

    }

    private fun createUserAccount(){
        //3 create user acount- firebase auth

        //show progress
        progressDialog.setMessage("Creating account")
        progressDialog.show()

        // create user in firbase
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                // account created, now add user info in db
                updateUserInfo()
                finish()
            }
            .addOnFailureListener{ e->
                // failed creating acocunt
                progressDialog.dismiss()
                Toast.makeText(this, "Failed creating account due to ${e.message}", Toast.LENGTH_SHORT).show()

            }
    }

    private fun updateUserInfo() {
        // 4 save user info - firebase realtime database

        progressDialog.setMessage("Saving user info")

        //timesatamp
        val timestamp = System.currentTimeMillis()

        // get current user uid since user is registered so we can get it now
        val user = auth.currentUser
        val uid = user!!.uid

        // setup data to add in db
        val hashMap: HashMap<String, Any?> = HashMap()
        hashMap["uid"] = uid
        hashMap["email"] = email
        hashMap["name"] = username
        hashMap["timestamp"] = timestamp

        //set data to db
        //val ref = FirebaseDatabase.getInstance().getReference("Users")
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        //val ref = database.getReference("Users")

        database.child("Users").child(uid)
            .setValue(hashMap)
            .addOnSuccessListener {
                // user info saved, open main activity
                progressDialog.dismiss()
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this@Register, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                // failed adding data to db
                progressDialog.dismiss()
                Toast.makeText(this, "Failed saving user info due to ${e.message}", Toast.LENGTH_SHORT).show()

            }

    }
}