package com.example.myapplication3.ui.recomendations

import androidx.lifecycle.ViewModel

class RecomendationsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}