package com.example.myapplication3

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication3.databinding.ActivityPdfEditBinding
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class PDFEditActivity: AppCompatActivity(){

    private lateinit var binding: ActivityPdfEditBinding

    private companion object {
        private const val TAG = "PDF_EDIT_TAG"
    }

    private var pdfId = ""

    private lateinit var progressDialog: ProgressDialog


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pdfId = intent.getStringExtra("pdfId")!!

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setCanceledOnTouchOutside(false)

        loadBookInfo()


        binding.updateBook.setOnClickListener {
            validateData()

        }

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }
    }



    private var title = ""
    private var description = ""
    private fun validateData() {
        // get data
        title = binding.titleNew.text.toString().trim()
        description = binding.bookEditDescription.text.toString().trim()

        // validate data
        if (title.isEmpty()){
            Toast.makeText(this, "Enter title", Toast.LENGTH_SHORT).show()
        }
        else if (description.isEmpty()){
            Toast.makeText(this, "Enter description", Toast.LENGTH_SHORT).show()
        }
        else {
            updatePdf()
        }

    }

    private fun updatePdf() {
        Log.d(TAG, "updatePdf: Starting updating pdf information...")

        progressDialog.setMessage("Updating book information")
        progressDialog.show()

        val hashMap = HashMap<String, Any>()
        hashMap["title"] = "$title"
        hashMap["description"] = "$description"

        // start update
        val ref = Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Books").child(pdfId)
            .updateChildren(hashMap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Log.d(TAG, "updatePdf: Updated successfully...")
                Toast.makeText(this, "Updated successfully...", Toast.LENGTH_SHORT).show()

                // Redirect to MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                Log.d(TAG, "updatePdf: Failed to update due to {$e.message}")
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to update due to {$e.message}", Toast.LENGTH_SHORT).show()
            }
    }

//    private fun loadBookInfo() {
//        Log.d(TAG, "loadBookInfo: Loading book info...")
//        val ref =
//            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
//        ref.child("Books")
//            .addValueEventListener(object : ValueEventListener {
//                override fun onDataChange(snapshot: DataSnapshot) {
//                    val description = snapshot.child("description").value.toString()
//                    val title = snapshot.child("title").value.toString()
//
//                    binding.titleNew.setText(title)
//                    binding.bookEditDescription.setText(description)
//
//
//
//                }
//
//                override fun onCancelled(error: DatabaseError) {
//                    // Handle onCancelled event
//                }
//            })
//    }
    private fun loadBookInfo() {
        Log.d(TAG, "loadBookInfo: Loading book info...")
        val ref = Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Books").child(pdfId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val description = snapshot.child("description").value.toString()
                        val title = snapshot.child("title").value.toString()

                        binding.titleNew.setText(title)
                        binding.bookEditDescription.setText(description)
                    } else {
                        Log.d(TAG, "loadBookInfo: PDF with id $pdfId does not exist")
                        Toast.makeText(this@PDFEditActivity, "PDF not found", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.d(TAG, "loadBookInfo: onCancelled - $error")
                    // Handle onCancelled event
                }
            })
    }

}
