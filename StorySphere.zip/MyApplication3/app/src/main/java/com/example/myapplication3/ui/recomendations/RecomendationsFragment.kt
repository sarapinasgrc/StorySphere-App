package com.example.myapplication3.ui.recomendations

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.myapplication3.R

class RecomendationsFragment : Fragment() {

    companion object {
        fun newInstance() = RecomendationsFragment()
    }

    private lateinit var viewModel: RecomendationsViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_recomendations, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(RecomendationsViewModel::class.java)
        // TODO: Use the ViewModel
    }

}