package com.example.myapplication3.ui.wanttoread

import androidx.lifecycle.ViewModel

class WantToReadViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}