package com.example.myapplication3.ui.bookstores

import androidx.lifecycle.ViewModel

class BookstoresViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}