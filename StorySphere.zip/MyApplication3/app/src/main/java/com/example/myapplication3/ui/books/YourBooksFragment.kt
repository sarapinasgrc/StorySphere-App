package com.example.myapplication3.ui.books

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication3.AdapterPDF
import com.example.myapplication3.DisplayPDF
import com.example.myapplication3.PDFListActivity
import com.example.myapplication3.R
import com.example.myapplication3.databinding.FragmentYourBooksBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class YourBooksFragment : Fragment() {

    companion object {
        fun newInstance() = YourBooksFragment()
        private const val LOCATION_PERMISSION_REQUEST_CODE = 100
        private const val PREFS_NAME = "LocationPermissionPrefs"
        private const val PREFS_KEY_PERMISSION_ASKED = "LocationPermissionAsked"
    }

    private lateinit var binding: FragmentYourBooksBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private val pdfArrayList: ArrayList<DisplayPDF> = ArrayList()
    private lateinit var adapterPdf: AdapterPDF
    private lateinit var viewModel: YourBooksViewModel
    private lateinit var sharedPreferences: SharedPreferences


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentYourBooksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        firebaseAuth = FirebaseAuth.getInstance()
        loadPdfList()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(YourBooksViewModel::class.java)

        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is not granted, request it
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            // Permission has been granted, proceed with location-related operations
            // You can start using location services here
        }


    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    // Permission granted, proceed with location-related operations
                    // You can start using location services here
                } else {
                    // Permission denied, handle it gracefully
                }
                return
            }
        }
    }

    private fun isLocationPermissionAlreadyAsked(): Boolean {
        return sharedPreferences.getBoolean(PREFS_KEY_PERMISSION_ASKED, false)
    }

    private fun markLocationPermissionAsked() {
        sharedPreferences.edit().putBoolean(PREFS_KEY_PERMISSION_ASKED, true).apply()
    }


    private fun loadPdfList() {
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        val user = firebaseAuth.currentUser
        val ref = database.child("Books")

        adapterPdf = AdapterPDF(requireContext(), pdfArrayList)
        binding.bookRv.adapter = adapterPdf

        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                pdfArrayList.clear()
                for (ds in snapshot.children) {
                    val uid = ds.child("uid").getValue(String::class.java)
                    if (uid == user?.uid) {
                        val model = ds.getValue(DisplayPDF::class.java)
                        model?.let {
                            pdfArrayList.add(it)
                        }
                    }
                }
                adapterPdf.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled event
            }
        })


    }
}

