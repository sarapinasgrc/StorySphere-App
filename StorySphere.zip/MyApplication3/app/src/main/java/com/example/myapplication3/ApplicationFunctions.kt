package com.example.myapplication3

import android.app.Application
import android.app.ProgressDialog
import android.content.Context
import java.util.*
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.github.barteksc.pdfviewer.PDFView
import com.google.firebase.Firebase
import com.google.firebase.database.database
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.storage
import com.google.firebase.storage.storageMetadata


class ApplicationFunctions: Application() {

    companion object{
        // convert timestamp to proper date format
        fun formatTimestamp(timestamp: Long) : String{
            val cal = Calendar.getInstance(Locale.ENGLISH)
            cal.timeInMillis = timestamp
            // format dd/MM/yyyy
            return DateFormat.format("dd/MM/yyyy", cal).toString()
        }




        // function to get pdf size
        fun loadPdfSize(pdfURL: String, pdfTitle:String, sizeTv: TextView) {
            val TAG = "PDF_SIZE_TAG"
            // using url we can get file and its metadata from firebase storage
            //val ref = Firebase.storage.getInstance().getReferenceFromUrl(pdfURL)
            //val database = Firebase.database
            val ref = Firebase.storage.getReferenceFromUrl(pdfURL)
            ref.metadata
                .addOnSuccessListener { storageMetadata ->
                    Log.d(TAG, "loadPDFSize: got metadata")
                    val bytes = storageMetadata.sizeBytes.toDouble()
                    Log.d(TAG, "loadPDFSize: sizeBytes $bytes")

                    // convert bytes to KB/MB
                    val kb = bytes / 1024
                    val mb = kb / 1024
                    if (mb > 1) {
                        sizeTv.text = "${String.format("%.2f", mb)} MB"
                    } else if (kb >= 1) {
                        sizeTv.text = "${String.format("%.2f", kb)} KB"
                    } else {
                        sizeTv.text = "${String.format("%.2f", bytes)} bytes"
                    }
            }
                .addOnFailureListener { e ->
                // failed to get metadata
                Log.d(TAG, "loadPDFSize: Failed to get metadata due to ${e.message}")
            }
        }

    fun loadPdfFromUrlSinglePage(
        pdfURL: String,
        pdfTitle:String,
        pdfView: PDFView,
        progressBar: ProgressBar,
        pagesTv: TextView?
    ) {
        // using url we can get file and is metadata from firebase storage
        val TAG = "PDF_THUMBNAIL_TAG"
        // using url we can get file and its metadata from firebase storage
        //val ref = Firebase.storage.getInstance().getReferenceFromUrl(pdfURL)
        val ref = Firebase.storage.getReferenceFromUrl(pdfURL)
        ref.getBytes(Constants.MAX_BYTES_PDF)
            .addOnSuccessListener { bytes ->
                Log.d(TAG, "loadPDFSize: Size Bytes $bytes")
                // SET TO PDF VIEW
                pdfView.fromBytes(bytes)
                    .pages(0) // show first page only
                    .spacing(0)
                    .swipeHorizontal(false)
                    .enableSwipe(false)
                    .onError { t ->
                        progressBar.visibility = View.INVISIBLE
                        Log.d(TAG, "loadPdfFromUrlSinglePage: ${t.message}")
                    }
                    .onPageError {page, t ->
                        progressBar.visibility = View.INVISIBLE
                        Log.d(TAG, "loadPdfFromUrlSinglePage: ${t.message}")

                    }
                    .onLoad{ nbPages ->
                        progressBar.visibility = View.INVISIBLE
                        Log.d(TAG, "loadPdfFromUrlSinglePage: Pages: $nbPages")
                        if (pagesTv != null) {
                            pagesTv.text = "$nbPages"
                        }
                    }
                    .load()

        }
            .addOnFailureListener { e ->
            // failed to get metadata
            Log.d(TAG, "loadPDFSize: Failed to get metadata due to ${e.message}")
        }

    }

        fun deleteBook(context: Context, pdfId: String, pdfUrl: String, pdfTitle: String){
            // param details

            val TAG = "DELETE_BOOK_TAG"

            Log.d(TAG, "deteletePDF: deleting...")

            val progressDialog = ProgressDialog(context)
            progressDialog.setTitle("Please wait")
            progressDialog.setMessage("Deleting $pdfId...")
            progressDialog.setCanceledOnTouchOutside(false)
            progressDialog.show()

            Log.d(TAG, "deteletePDF: deleting from storage...")

            val storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(pdfUrl)
            storageReference.delete()
                .addOnSuccessListener {
                    Log.d(TAG, "deletePDF: Deleted from storage")
                    Toast.makeText(context, "Deleting from db now...", Toast.LENGTH_SHORT).show()

                    val ref = Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
                    ref.child("Books").child(pdfId)
                        .removeValue()
                        .addOnSuccessListener {
                            progressDialog.show()
                            Toast.makeText(context, "Successfully deleted...", Toast.LENGTH_SHORT).show()
                            Log.d(TAG, "Deleted from db too...")
                            progressDialog.dismiss()


                        }
                        .addOnFailureListener { e ->
                            progressDialog.dismiss()
                            Log.d(TAG, "deletePDF: Failed to delete due to {$e.message}")
                            Toast.makeText(context, "Failed to delete due to {$e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Log.d(TAG, "deletePDF: Failed to delete from storage due to {$e.message}")
                    Toast.makeText(
                        context,
                        "Failed to delete from storage due to {$e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

        }

        fun deleteReview(context: Context, reviewId: String) {
            // param details

            val TAG = "DELETE_REVIEW_TAG"

            Log.d(TAG, "deteleteReview: deleting...")

            val progressDialog = ProgressDialog(context)
            progressDialog.setTitle("Please wait")
            progressDialog.setMessage("Deleting $reviewId...")
            progressDialog.setCanceledOnTouchOutside(false)
            progressDialog.show()

            Log.d(TAG, "deteleteReview: deleting from db...")


            val ref =
                Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
            ref.child("Reviews").child(reviewId)
                .removeValue()
                .addOnSuccessListener {
                    progressDialog.show()
                    Toast.makeText(context, "Successfully deleted...", Toast.LENGTH_SHORT).show()
                    Log.d(TAG, "Deleted from db...")
                    progressDialog.dismiss()
                }
                .addOnFailureListener { e ->
                    progressDialog.dismiss()
                    Log.d(TAG, "deleteReview: Failed to delete due to {$e.message}")
                    Toast.makeText(
                        context,
                        "Failed to delete due to {$e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }


        }


    }
}



