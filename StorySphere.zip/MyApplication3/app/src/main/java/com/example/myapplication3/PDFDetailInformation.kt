package com.example.myapplication3

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication3.databinding.ActivityPdfDetailBinding
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class PDFDetailInformation : AppCompatActivity() {
    private lateinit var binding: ActivityPdfDetailBinding

    private var pdfId = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pdfId = intent.getStringExtra("pdfId")!!



        loadBookDetails()

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

        // open pdf

        binding.readBookBtn.setOnClickListener{
            val intent = Intent(this, PDFViewActivity::class.java)
            intent.putExtra("pdfId", pdfId)
            startActivity(intent)
        }




    }

    private fun loadBookDetails() {
        val ref = Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Books").child(pdfId)
            .addListenerForSingleValueEvent(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // get data
                    val description = "${snapshot.child("description").value}"
                    val timestamp = "${snapshot.child("timestamp").value}"
                    val title = "${snapshot.child("title").value}"
                    val uid = "${snapshot.child("uid").value}"
                    val url = "${snapshot.child("url").value}"

                    // format date
                    val date = ApplicationFunctions.formatTimestamp(timestamp.toLong())


                    ApplicationFunctions.loadPdfFromUrlSinglePage("$url", "$title", binding.pdfView, binding.progressBar, null)
                    ApplicationFunctions.loadPdfSize("$url", "$title", binding.sizeTv)



                    binding.titleTv.text = title
                    binding.descriptionTv.text = description
                    binding.dateTv.text = date





                }

                override fun onCancelled(error: DatabaseError) {

                }


            })
    }

}