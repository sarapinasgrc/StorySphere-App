package com.example.myapplication3

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.text.isDigitsOnly
import com.example.myapplication3.databinding.ActivityGoalsSettingsBinding
import com.example.myapplication3.databinding.ActivityRegisterBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.database

class GoalsSettings : AppCompatActivity() {

    private lateinit var binding: ActivityGoalsSettingsBinding

    //firebase auth
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth


    //progress dialog
    private lateinit var progressDialog: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =  ActivityGoalsSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.bb.setOnClickListener {
            onBackPressed()
        }

        binding.save.setOnClickListener {
            validateData()
        }

    }

    private var readinggoals = ""
    private var bread = ""
    private var tread  = ""
    private fun validateData() {
        readinggoals = binding.objetivereading.text.toString().trim()
        bread= binding.booksread.text.toString().trim()
        tread= binding.timeread.text.toString().trim()

        if (readinggoals.isNotEmpty() && !readinggoals.isDigitsOnly()) {
            // Handle non-numeric value for readinggoals
            // You can show an error message or handle it as needed
            Toast.makeText(this, "Enter a number as your reading goal!", Toast.LENGTH_SHORT).show()
        }
        if (bread.isNotEmpty() && !bread.isDigitsOnly()) {
            // Handle non-numeric value for readinggoals
            // You can show an error message or handle it as needed
            Toast.makeText(this, "Enter a number as your books read!", Toast.LENGTH_SHORT).show()
        }
        if (tread.isNotEmpty() && !tread.isDigitsOnly()) {
            // Handle non-numeric value for readinggoals
            // You can show an error message or handle it as needed
            Toast.makeText(this, "Enter a number as your time read!", Toast.LENGTH_SHORT).show()
        }
        else{
            updateData()
        }
    }

    private fun updateData() {


        val timestamp = System.currentTimeMillis()
        // get current user uid since user is registered so we can get it now
        val user = auth.currentUser
        val uid = user!!.uid

        val hashmap: HashMap<String, Any> = HashMap()
        hashmap["uid"] = uid

        if (readinggoals.isNotEmpty()) {
            hashmap["reading_objective"] = readinggoals
        }
        if (bread.isNotEmpty()) {
            hashmap["books_read"] = bread
        }
        if (tread.isNotEmpty()) {
            hashmap["time_read"] = tread
        }

        hashmap["timestamp"] = timestamp

        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        database.child("Users").child(uid)
            .updateChildren(hashmap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Goals updated successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {e ->
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to update goals due to ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

