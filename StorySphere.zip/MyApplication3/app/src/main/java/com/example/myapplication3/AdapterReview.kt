package com.example.myapplication3

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication3.databinding.ActivityDisplayBookreviewBinding

class AdapterReview : RecyclerView.Adapter<AdapterReview.HolderReviewAdmin> {
    // context
    private var context: Context

    // array list to hold pdfs
    var reviewArrayList: ArrayList<DisplayReview>
    //private val filterList:ArrayList<DisplayPDF>

    // view Binding
    private lateinit var binding: ActivityDisplayBookreviewBinding


    // constructor
    constructor(context: Context, reviewArrayList: ArrayList<DisplayReview>) : super() {
        this.context = context
        this.reviewArrayList = reviewArrayList
        //this.filterList = pdfArrayList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderReviewAdmin {
        //bind/inflate layout activity_display_book.xml
        binding =
            ActivityDisplayBookreviewBinding.inflate(LayoutInflater.from(context), parent, false)
        return HolderReviewAdmin(binding.root)
    }

    override fun onBindViewHolder(holder: AdapterReview.HolderReviewAdmin, position: Int) {
        /*get data, set data, handle click, etc*/
        // get data
        val model = reviewArrayList[position]
        val reviewId = model.id
        val title = model.title
        val review = model.review
        val score = model.score
        val timestamp = model.timestamp
        // convert timestamp to dd/MM/yyyy
        val formattedDate = ApplicationFunctions.formatTimestamp(timestamp)

        // create Application class that contains the functions that will be used multiple times in the app

        // set data
        holder.titleTv.text = title
        holder.reviewTv.text = review
        holder.scoreTv.text = score.toString()
        holder.dateTv.text = formattedDate


        // handle click, show dialog with 1) Edit and 2) Delete Book
        holder.moreBtn.setOnClickListener {
            moreOptionsDialog(model, holder)
        }

        // handle item click, open ReadReview
        holder.itemView.setOnClickListener {
            val intent = Intent(context, ReviewDisplayActivity::class.java)
            intent.putExtra("reviewId", reviewId)
            context.startActivity(intent)
        }


    }

    private fun moreOptionsDialog(model: DisplayReview, holder: AdapterReview.HolderReviewAdmin) {
        val reviewId = model.id

        // options to show in dialog
        val options = arrayOf("Edit", "Delete")

        // alert dialog
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Choose Option")
            .setItems(options) { dialog, position ->
                // handle item click
                if (position == 0) {
                    // Edit is clicked
                    val intent = Intent(context, ReviewEditActivity::class.java)
                    intent.putExtra("reviewId", reviewId)
                    context.startActivity(intent)
                } else if (position == 1) {
                    // Delete is clicked

                    ApplicationFunctions.deleteReview(context, reviewId)
                }
            }
            .show()
    }


    override fun getItemCount(): Int {
        return reviewArrayList.size //items count
    }


    //override fun getFilter(): Filter {
    //    if (filter == null){
    //        //filter = FilterPDF(filterList, this)
    //    }
    //    return filter as FilterPDF
    //}

    inner class HolderReviewAdmin(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // UI views of activity_display_book.xml

        val titleTv = binding.titleTv
        val reviewTv = binding.reviewTv
        val scoreTv = binding.scoreTv
        val dateTv = binding.dateTv
        val moreBtn = binding.moreBtn
    }


}

