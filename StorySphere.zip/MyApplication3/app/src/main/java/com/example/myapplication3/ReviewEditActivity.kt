package com.example.myapplication3

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.Toast
import com.example.myapplication3.databinding.ActivityReviewEditBinding
import com.google.firebase.Firebase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class ReviewEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReviewEditBinding

    private companion object {
        private const val TAG = "REVIEW_EDIT_TAG"
    }

    private var reviewId = ""

    private lateinit var progressDialog: ProgressDialog


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewEditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        reviewId = intent.getStringExtra("reviewId")!!

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setCanceledOnTouchOutside(false)

        loadReviewInfo()


        binding.updateReview.setOnClickListener {
            validateData()

        }

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }
    }


    private var title = ""
    private var score = ""
    private var review = ""
    private fun validateData() {
        // get data
        title = binding.titleNew.text.toString().trim()
        score = binding.scoreNew.text.toString().trim()
        review = binding.reviewEditDescription.text.toString().trim()

        // validate data
        if (title.isEmpty()) {
            Toast.makeText(this, "Enter title", Toast.LENGTH_SHORT).show()
        } else if (review.isEmpty()) {
            Toast.makeText(this, "Enter description", Toast.LENGTH_SHORT).show()
        } else if (score.isEmpty()) {
            Toast.makeText(this, "Enter score", Toast.LENGTH_SHORT).show()
        } else {
            updateReview()
        }

    }

    private fun updateReview() {
        Log.d(TAG, "updateReview: Starting updating review information...")

        progressDialog.setMessage("Updating review information")
        progressDialog.show()

        val hashMap = HashMap<String, Any>()
        val score = score.toDoubleOrNull()
        hashMap["title"] = "$title"
        hashMap["review"] = "$review"
        if (score != null) {
            hashMap["score"] = score
        } else {
            // Handle case where conversion fails
            Toast.makeText(
                this,
                "Score cannot be converted to Double and is Null",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }

        // start update
        val ref =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Review").child(reviewId)
            .updateChildren(hashMap)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Log.d(TAG, "updateReview: Updated successfully...")
                Toast.makeText(this, "Updated successfully...", Toast.LENGTH_SHORT).show()

                // Redirect to MainActivity
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                Log.d(TAG, "updateReview: Failed to update due to {$e.message}")
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to update due to {$e.message}", Toast.LENGTH_SHORT)
                    .show()
            }
    }


    private fun loadReviewInfo() {
        Log.d(TAG, "loadReviewInfo: Loading review info...")
        val ref =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference
        ref.child("Reviews").child(reviewId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val review = snapshot.child("review").value.toString()
                        val title = snapshot.child("title").value.toString()
                        val score = snapshot.child("score").value.toString()

                        binding.titleNew.setText(title)
                        binding.scoreNew.setText(score)
                        binding.reviewEditDescription.setText(review)
                    } else {
                        Log.d(TAG, "loadReviewInfo: Review with id $reviewId does not exist")
                        Toast.makeText(
                            this@ReviewEditActivity,
                            "Review not found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.d(TAG, "loadReviewInfo: onCancelled - $error")
                    // Handle onCancelled event
                }
            })
    }

}
