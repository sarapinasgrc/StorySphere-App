package com.example.myapplication3.ui.bookstores

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication3.R
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment

class BookstoresFragment : Fragment(), OnMapReadyCallback {

    public lateinit var map: GoogleMap

    companion object {
        fun newInstance() = BookstoresFragment()
        const val REQUEST_CODE_LOCATION = 100
    }

    private lateinit var viewModel: BookstoresViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.activity_map_book_store, container, false)
        createMapFragment()
        return rootView
    }
    private fun createMapFragment() {
        val mapFragment: SupportMapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(BookstoresViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        enableLocation()
    }

    private fun isLocationPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun enableLocation() {
        if (!::map.isInitialized) return
        if (isLocationPermissionGranted()) {
            map.isMyLocationEnabled = true
        } else {
            requestLocationPermission()
        }
    }
    private fun showPermissionDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Location Permission")
            .setMessage("This app requires location permissions to show your current location.")
            .setPositiveButton("Allow") { _, _ ->
                requestPermissions(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    REQUEST_CODE_LOCATION
                )
            }
            .setNegativeButton("Deny") { _, _ ->
                // Handle permission denial
                Toast.makeText(
                    requireContext(),
                    "Location permission denied. You can grant the permission in the app settings.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .show()
    }

    private fun requestLocationPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(
                requireActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        ) {
            // Explain why the app needs location permissions
            showPermissionDialog()
        } else {
            // Request the permission
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_CODE_LOCATION
            )
        }
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_LOCATION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, enable the location
                enableLocation()
            } else {
                // Permission denied, show a message
                Toast.makeText(
                    requireContext(),
                    "Location permission denied. You can grant the permission in the app settings.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }


}