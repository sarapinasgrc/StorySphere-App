package com.example.myapplication3

import android.app.Application
//import android.app.Instrumentation.ActivityResult
import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.registerForActivityResult
import com.example.myapplication3.databinding.ActivityPdfbookBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.storage
import java.net.URI
import androidx.activity.result.ActivityResult
import com.google.firebase.database.database

class PDFbook : AppCompatActivity() {

    // viewbinding
    private lateinit var binding: ActivityPdfbookBinding

    //firbase auth
    private lateinit var firebaseAuth: FirebaseAuth

    //progress dialog
    private lateinit var progressDialog: ProgressDialog

    //uri of picker pdf
    private var pdfUri: Uri? = null

    private val TAG = "PDF_ADD_TAG"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfbookBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()


        // init progress dialog, will show while login account/ login user
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setCanceledOnTouchOutside(false)


        // handle click, pick pdf intent
        binding.addabook.setOnClickListener{
            pdfPickIntent()
        }

        // start uploading a pdf
        binding.addthisbook.setOnClickListener {
            // Validar datos
            // Upload pdf to firebase
            //Get url of uploading pdf
            //Upload pdf info to firebase
            validateData()
        }

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

    }

    private var title = ""
    private var description = ""
    private fun validateData() {
        Log.d(TAG, "validateData: validating data")

        title = binding.titleTv.text.toString().trim()
        description = binding.bookdescription.text.toString().trim()

        if (title.isEmpty()) {
            Toast.makeText(this, "Enter title", Toast.LENGTH_SHORT).show()
        } else if (description.isEmpty()) {
            Toast.makeText(this, "Enter description", Toast.LENGTH_SHORT).show()
        } else if (pdfUri == null) {
            Toast.makeText(this, "Pick a PDF", Toast.LENGTH_SHORT).show()
        }
        else{
            uploadPDFToStorage()
        }
    }

    private fun uploadPDFToStorage() {
        Log.d(TAG, "uploadPDFStorage: uploading to storage")

        progressDialog.setMessage("Uploading PDF")
        progressDialog.show()

        val timestamp = System.currentTimeMillis()
        // val storage = Firebase.storage
        val filePathAndName = "Books/$timestamp"

        val storageReference = FirebaseStorage.getInstance().getReference(filePathAndName)
        //val storageReference = storage.reference
        //val Bookref = storageReference.child(filePathAndName)
        storageReference.putFile(pdfUri!!)
            .addOnSuccessListener{ taskSnapshot->
                Log.d(TAG, "uploadPDFToStorage: PDF uploaded")
                val uriTask: Task<Uri> = taskSnapshot.storage.downloadUrl
                while (!uriTask.isSuccessful);
                val uploadPDFUrl = "${uriTask.result}"

                uploadPdfinfoToDb(uploadPDFUrl, timestamp)
                finish()
            }
            .addOnFailureListener{e ->
                Log.d(TAG, "uploadPDFToStorage: failed to upload due to ${e.message}")
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to upload due to ${e.message}", Toast.LENGTH_SHORT).show()

            }
    }

    private fun uploadPdfinfoToDb(uploadPDFUrl: String, timestamp: Long) {

        Log.d(TAG, "uploadPdfinfoToDb: uploading to database")
        progressDialog.setMessage("Uploading PDF to the database")

        val uid = firebaseAuth.uid

        val hashMap: HashMap<String, Any?> = HashMap()
        hashMap["uid"] = "$uid"
        hashMap["id"] = "$timestamp"
        hashMap["title"] = "$title"
        hashMap["description"] = "$description"
        hashMap["url"] = "$uploadPDFUrl"
        hashMap["timestamp"] = timestamp

        //hashMap["uid"] = uid
        //hashMap["id"] = "$timestamp"
        //hashMap["title"] = title
        //hashMap["description"] = description
        //hashMap["url"] = uploadPDFUrl
        //hashMap["timestamp"] = timestamp
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        val ref = database.child("Books")
        ref.child("$timestamp")
            .setValue(hashMap)
            .addOnSuccessListener {
                Log.d(TAG, "uploadPdfinfoToDb: uploaded to db")
                progressDialog.dismiss()
                Toast.makeText(this, "Uploaded", Toast.LENGTH_SHORT).show()
                pdfUri = null
                startActivity(Intent(this@PDFbook, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                Log.d(TAG, "uploadPdfinfoToDb: failed to upload due to ${e.message}")
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to upload due to ${e.message}", Toast.LENGTH_SHORT).show()
                finish()
            }

    }


    private fun pdfPickIntent(){
        Log.d(TAG, "pdfPickIntent: starting pdf pick intent")

        val intent = Intent()
        intent.type = "application/pdf"
        intent.action = Intent.ACTION_GET_CONTENT
        pdfActivityResultLauncher.launch(intent)
    }

    val pdfActivityResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
        ActivityResultCallback<ActivityResult> { result ->
            if (result.resultCode == RESULT_OK){
                Log.d(TAG, "PDF picked")
                pdfUri = result.data!!.data
            }
            else {
                Log.d(TAG, "PDF Pick cancelled")
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    )

}