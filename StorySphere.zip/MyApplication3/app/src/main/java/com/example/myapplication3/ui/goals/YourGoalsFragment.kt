package com.example.myapplication3.ui.goals

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.content.Intent
import android.widget.TextView
import com.example.myapplication3.GoalsSettings
import com.example.myapplication3.R
import com.example.myapplication3.databinding.FragmentYourGoalsBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database

class YourGoalsFragment : Fragment() {

    companion object {
        fun newInstance() = YourGoalsFragment()
    }

    private lateinit var viewModel: YourGoalsViewModel
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth


    private lateinit var binding: FragmentYourGoalsBinding
    val database =
        Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        return inflater.inflate(R.layout.fragment_your_goals, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(YourGoalsViewModel::class.java)
        // TODO: Use the ViewModel
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val numberGoalsTextView = view.findViewById<TextView>(R.id.numbergoals)
        val numberBooksTextView = view.findViewById<TextView>(R.id.numberbooks)
        val numberTimeTextView = view.findViewById<TextView>(R.id.numbertime)

        loadInfo(numberGoalsTextView, numberBooksTextView, numberTimeTextView)

        //val button = view.findViewById<ImageButton>(R.id.edit)
        val b = view.findViewById<ImageButton>(R.id.editbtn)

        // Set click listener for the button
        b.setOnClickListener {
            val intent = Intent(activity, GoalsSettings::class.java)
            startActivity(intent)
        }

    }

    private fun loadInfo(
        numberGoalsTextView: TextView,
        numberBooksTextView: TextView,
        numberTimeTextView: TextView) {
        auth = Firebase.auth
        firebaseAuth = FirebaseAuth.getInstance()
        val user = firebaseAuth.currentUser!!
        val uid = user.uid
        database.child("Users").child(uid).addValueEventListener(
            object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val user_reading_goal = dataSnapshot.child("reading_objective").value.toString()
                    val user_reading_book = dataSnapshot.child("books_read").value.toString()
                    val user_reading_time = dataSnapshot.child("time_read").value.toString()

                    numberGoalsTextView.text = user_reading_goal
                    numberBooksTextView.text = user_reading_book
                    numberTimeTextView.text = user_reading_time
                }
                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            }
        )
    }


}