package com.example.myapplication3

import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.Toast
import com.example.myapplication3.databinding.ActivityPdfbookBinding
import com.example.myapplication3.databinding.ActivityReviewbookBinding
import com.google.android.gms.tasks.Task
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.database
import com.google.firebase.storage.FirebaseStorage

class Reviewbook : AppCompatActivity() {

    // viewbinding
    private lateinit var binding: ActivityReviewbookBinding

    //firbase auth
    private lateinit var firebaseAuth: FirebaseAuth

    //progress dialog
    private lateinit var progressDialog: ProgressDialog

    private val TAG = "REVIEW_ADD_TAG"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReviewbookBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()


        // init progress dialog, will show while login account/ login user
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setCanceledOnTouchOutside(false)


        // start uploading a pdf
        binding.addthisreview.setOnClickListener {
            // Validar datos
            // Upload review to db
            validateData()
        }

        val button = findViewById<ImageButton>(R.id.backbutton)
        button.setOnClickListener {

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

    }

    private var title = ""
    private var score = ""
    private var review = ""
    private fun validateData() {
        Log.d(TAG, "validateData: validating data")

        title = binding.titleTv.text.toString().trim()
        score = binding.scoreTv.text.toString().trim()
        review = binding.bookreview.text.toString().trim()

        if (title.isEmpty()) {
            Toast.makeText(this, "Enter title", Toast.LENGTH_SHORT).show()
        } else if (score.isEmpty()) {
            Toast.makeText(this, "Enter score", Toast.LENGTH_SHORT).show()
        } else if (review.isEmpty()) {
            Toast.makeText(this, "Enter review", Toast.LENGTH_SHORT).show()
        } else {
            uploadReviewToDb()
        }
    }

    private fun uploadReviewToDb() {

        Log.d(TAG, "uploadReviewToDb: uploading to database")
        progressDialog.setMessage("Uploading Review to the database")

        val timestamp = System.currentTimeMillis()

        val uid = firebaseAuth.uid
        val hashMap: HashMap<String, Any?> = HashMap()
        val score = score.toDoubleOrNull()

        hashMap["uid"] = "$uid"
        hashMap["id"] = "$timestamp"
        hashMap["title"] = "$title"
        if (score != null) {
            hashMap["score"] = score
        } else {
            // Handle case where conversion fails
            Toast.makeText(
                this,
                "Score cannot be converted to Double and is Null",
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
        hashMap["review"] = "$review"
        hashMap["timestamp"] = timestamp

        //hashMap["uid"] = uid
        //hashMap["id"] = "$timestamp"
        //hashMap["title"] = title
        //hashMap["description"] = description
        //hashMap["url"] = uploadPDFUrl
        //hashMap["timestamp"] = timestamp
        val database =
            Firebase.database("https://uc3m-it-2024-16504-g13-default-rtdb.europe-west1.firebasedatabase.app/").reference

        val ref = database.child("Reviews")
        ref.child("$timestamp")
            .setValue(hashMap)
            .addOnSuccessListener {
                Log.d(TAG, "uploadReviewToDb: uploaded to db")
                progressDialog.dismiss()
                Toast.makeText(this, "Uploaded", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this@Reviewbook, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener { e ->
                Log.d(TAG, "uploadReviewToDb: failed to upload due to ${e.message}")
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to upload due to ${e.message}", Toast.LENGTH_SHORT)
                    .show()
                startActivity(Intent(this@Reviewbook, MainActivity::class.java))
                finish()
            }


    }
}
