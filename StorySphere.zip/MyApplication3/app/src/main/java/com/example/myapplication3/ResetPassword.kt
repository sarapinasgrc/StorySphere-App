package com.example.myapplication3

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import com.example.myapplication3.databinding.ActivityPdfbookBinding
import com.example.myapplication3.databinding.ActivityResetPasswordBinding
import com.google.firebase.auth.FirebaseAuth

class ResetPassword : AppCompatActivity() {

     // view binding
    private lateinit var binding: ActivityResetPasswordBinding

    private lateinit var firebaseAuth: FirebaseAuth

    private lateinit var progressDialog: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please Wait")
        progressDialog.setCanceledOnTouchOutside(false)

        binding.emailbutton.setOnClickListener {
            validateData()
        }

        val button = findViewById<ImageButton>(R.id.backbutton2)
        button.setOnClickListener {

            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        //val button1 = findViewById<Button>(R.id.emailbutton)
        //button1.setOnClickListener {

            //val intent = Intent(this, EmailSent::class.java)
            //startActivity(intent)
        //}
    }

    private var email = ""
    private fun validateData() {
        email = binding.email.text.toString().trim()

        if (email.isEmpty()){
            Toast.makeText(this, "Enter email", Toast.LENGTH_SHORT).show()
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            Toast.makeText(this, "Invalid email", Toast.LENGTH_SHORT).show()
        }
        else{
            recoverPassword()
        }
    }

    private fun recoverPassword() {
        progressDialog.setMessage("Sending email to $email")
        progressDialog.show()

        firebaseAuth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
                progressDialog.dismiss()
                Toast.makeText(this, "Email sent", Toast.LENGTH_SHORT).show()

            }
            .addOnFailureListener {e->
                progressDialog.dismiss()
                Toast.makeText(this, "Failed to send email, due to ${e.message}", Toast.LENGTH_SHORT).show()


            }
    }
}