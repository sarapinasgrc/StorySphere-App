package com.example.myapplication3

object Constants {

    const val MAX_BYTES_PDF: Long = 5000000
}