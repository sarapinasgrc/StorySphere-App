package com.example.myapplication3

class DisplayReview {

    // variables
    var uid: String = ""
    var id: String = ""
    var title: String = ""
    var score: Long = 0
    var review: String = ""
    var timestamp: Long = 0
    //var viewsCount:Long = 0
    //var downloadsCount:Long = 0

    // empty constructor (required by firebase)
    constructor()


    // parametrized constructor

    constructor(
        uid: String,
        id: String,
        title: String,
        score: Long,
        review: String,
        timestamp: Long,
        //viewsCount: Long,
        //downloadsCount: Long
    ) {
        this.uid = uid
        this.id = id
        this.title = title
        this.review = review
        this.score = score
        this.timestamp = timestamp
        //this.viewsCount = viewsCount
        //this.downloadsCount = downloadsCount
    }


}