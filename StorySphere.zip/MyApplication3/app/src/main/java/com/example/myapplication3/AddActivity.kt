package com.example.myapplication3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication3.databinding.ActivityAddBinding
import com.google.android.material.snackbar.Snackbar

class AddActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddBinding.inflate(layoutInflater)

        setContentView(binding.root)


        binding.addbookBtn.setOnClickListener { view ->
            Snackbar.make(view, "Add new book", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            startActivity(Intent(this, PDFbook::class.java))
        }
        binding.reviewbookBtn.setOnClickListener { view ->
            Snackbar.make(view, "Add new book", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            startActivity(Intent(this, Reviewbook::class.java))
        }
    }
}
